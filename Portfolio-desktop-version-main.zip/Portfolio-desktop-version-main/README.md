![](https://img.shields.io/badge/Microverse-blueviolet)

# Portfolio desktop version

> This project is part of the Microverse Program in which is resquested to do a portifolio in a desktop version using responsiveness and media queries. This portifolio is where all of my projects are, as well as my skills, in which will be uploaded on it in the future. The structure of this project is basically a simple page in html and css file. It is also part of the sketelon of my future portifolio, but in a mobile and a desktop version.

## Built With

- HTML & CSS

## Authors

👤 **Mirela Santos Oliveira**

- GitHub: [@mirelapitt](https://github.com/mirelapitt)
- Twitter: [@devmirela](https://twitter.com/devmirela)
- LinkedIn: [LinkedIn](https://www.linkedin.com/in/mirela-oliveira-261893160/)


## 🤝 Contributing

Contributions, issues, and feature requests are welcome!

Feel free to check the [issues page](../../issues/).

## Show your support

Give a ⭐️ if you like this project!

## 📝 License

This project is [MIT](./MIT.md) licensed.
